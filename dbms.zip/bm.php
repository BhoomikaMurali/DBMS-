<?php
/*$mypdo = new PDO('mysql:host=localhost;dbname=power_app','root','amreezaba');
if($mypdo){
echo "connect";
} else {
echo "not connect";
}*/
?>
