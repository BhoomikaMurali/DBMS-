<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', 'amreezaba', 'temp');

	// initialize variables
	$room_id = "";
	$room_name = "";
	$update = false;

	if (isset($_POST['save'])) {
		$room_id = $_POST['id'];
		$room_name = $_POST['name'];

		mysqli_query($db, "INSERT INTO room (room_id, room_name) VALUES ('$room_id', '$room_name')"); 
		$_SESSION['message'] = "Room saved"; 
		header('location: admin.php');
  }

  if (isset($_POST['update'])) {
		$room_id = $_POST['id'];
		$room_name = $_POST['name'];    
  
    if(mysqli_query($db, "UPDATE room SET room_name='$room_name' where room_id=$room_id")) {
      header('location: admin.php');
    } else {
      mysqli_query($db, "INSERT INTO room (room_id, room_name) VALUES ('$room_id', '$room_name')");
    }
    $_SESSION['message'] = "Room updated!"; 
    header('location: admin.php');
  }
  
  if (isset($_GET['del'])) {
    $room_id = $_GET['del'];
    mysqli_query($db, "DELETE FROM room WHERE room_id=$room_id");
    $_SESSION['message'] = "Room deleted!"; 
    header('location: admin.php');
  }

?>
