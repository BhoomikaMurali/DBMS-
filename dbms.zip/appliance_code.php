<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', 'amreezaba', 'temp');

	// initialize variables
	$switch_id = "";
	$ea_name = "";
	$ea_id = 0;
	$update = false;

	if (isset($_POST['save'])) {
    	$switch_id = $_POST['id'];
		$appliance_name = $_POST['name'];

		mysqli_query($db, "INSERT INTO electronic_appliances (switch_id, ea_name) VALUES ('$switch_id', '$appliance_name')"); 
		$_SESSION['message'] = "appliance saved"; 
		header('location: appliance.php');
  }

  if (isset($_POST['update'])) {
		$switch_id = $_POST['id'];
		$appliance_name = $_POST['name'];
		$ea_id = $_POST['ea_id'];
    mysqli_query($db, "UPDATE electronic_appliances SET ea_name='$appliance_name', switch_id='$switch_id' where ea_id=$ea_id");
    $_SESSION['message'] = "appliance updated!"; 
    header('location: appliance.php');
  }
  
  if (isset($_GET['del'])) {
    $appliance_id = $_GET['del'];
    mysqli_query($db, "DELETE FROM electronic_appliances WHERE ea_id=$appliance_id");
    $_SESSION['message'] = "appliance deleted!"; 
    header('location: appliance.php');
  }

?>
