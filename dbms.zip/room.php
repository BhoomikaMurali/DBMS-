<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="">
    <h1>ENTER ROOM NUMBER</h1>
  <h2>
  <form action="conndb.php" method="POST">
  
  ROOM NUMBER: <br>
  <select name="realroomnumber">
<?php 
$myconn = mysqli_connect('localhost:3306','root','amreezaba','temp');
$sql = mysqli_query($myconn, "SELECT * FROM room");
while ($row = $sql->fetch_assoc()){
$id = $row['room_id'];
echo '<option value="'.$id.'">'.$id.'</option>';
}
?>
</select>
  <!-- <input type="int" name="realroomnumber"><br> -->
  
  
  <input class = "btn" type="submit" value="Submit"></h2>
  <input class = "btn" type="button" value="Go back" onclick="history.back()">

  
  
  </form></div>
<br>
  <a href="admin.php"><button class="btn">Go to admin</button></a>
  
</body>
  

</html>
