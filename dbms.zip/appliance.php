<?php  include('appliance_code.php'); ?>
<?php 
	if (isset($_GET['edit'])) {
		$ea_id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM electronic_appliances WHERE ea_id=$ea_id");

		if (count($record) == 1) {
			$n = mysqli_fetch_array($record);
			$ea_name = $n['ea_name'];
			$switch_id = $n['switch_id'];
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Appliance</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php $results = mysqli_query($db, "SELECT * FROM electronic_appliances"); ?>

<table>
	<thead>
		<tr>
			<th>Switch ID</th>
			<th>NAME</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['switch_id']; ?></td>
			<td><?php echo $row['ea_name']; ?></td>
			<td>
				<a href="appliance.php?edit=<?php echo $row['ea_id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="appliance_code.php?del=<?php echo $row['ea_id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
	<form method="post" action="appliance.php" >
		<input type="hidden" name="ea_id" value = "<?php echo $ea_id ?>">
		<div class="input-group">
			<label>Switch ID</label>
			<input type="text" name="id" value="<?php echo $switch_id ?>">
		</div>
		<div class="input-group">
			<label>Appliance Name</label>
			<input type="text" name="name" value="<?php echo $ea_name ?>">
		</div>
		<div class="input-group">
    <?php if ($update == true): ?>
	<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
<?php else: ?>
	<button class="btn" type="submit" name="save" >Save</button>
<?php endif ?>
		</div>
	</form>
</body>
</html>