<?php
$myconn = mysqli_connect('localhost:3306','root','amreezaba','temp');
if($myconn){
//$query = "select sw.switch_id as switchId,regulator_id,ea_name,socket_no from switch_box as sb join switch as sw on sb.switch_box_id = sw.switch_box_id  join regulator as re on sw.switch_id=re.switch_id join electronic_appliances as ele on sw.switch_id=ele.switch_id join socket as so on sw.switch_id=so.switch_id where sb.room_id".$_POST['realroomnumber'];
//$query = "select sw.switch_id as switchId, regulator_id,ea_name,socket_no from switch as sw left join regulator as re on sw.switch_id=re.switch_id left join electronic_appliances as ele on sw.switch_id=ele.switch_id left join socket as so on sw.switch_id=so.switch_id where room_id=".$_POST['realroomnumber'];
$query = "select sw.switch_id,regulator_id,ea_name,ea_id,socket_no from switch_box as sb join switch as sw on sb.switch_box_id = sw.switch_box_id left join regulator as re on sw.switch_id=re.switch_id left join electronic_appliances as ele on sw.switch_id=ele.switch_id left join socket as so on sw.switch_id=so.switch_id where sb.room_id=".$_POST['realroomnumber'];
$result = mysqli_query($myconn, $query);
echo "<table border=1> <tr> <th> Switch Id </th> <th> Regulator Id </th> <th> Appliance Name </th> <th> Appliances Id </th> <th> socket number </th></tr>";
while($row = mysqli_fetch_assoc($result))
{
$switch_id = $row['switch_id'];
$regulator_id = $row['regulator_id'];
$ea_name= $row['ea_name'];
$ea_id= $row['ea_id'];
$socket_no = $row['socket_no'];
echo "<tr> <td>". $switch_id . "</td><td> " . $regulator_id. "</td><td> ". $ea_name. "</td><td> " . $ea_id. "</td><td> ". $socket_no ."</td></tr>";
}
echo "</table>";
} else {
   echo "no";
}
?>
