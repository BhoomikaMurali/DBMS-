<html>
<head>
       <link rel="stylesheet" href="style.css">
<title>
   GECH - Individual room power appliances system
<link rel="icon" href="/var/html/project/BMM.png">

</title>

</head>
<body>
    
  <div class="nav">
<nav>
  <a href="#home">HOME</a>
  <a href="#aboutus">ABOUT US</a>
<a href="#gallery">GALLERY</a>
<a href="#contactus">LOGIN</a></div>
<div class="home">
  <h1 id="home">HOME</h1>

  <h2>
    Government Engineering College Hassan
  </h2>
  <h3> INDIVIDUAL ROOM POWER APPLIANCES INFORMATION SYSTEM</h3>

     
  <br>

  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
</div>
<div class="aboutus">
  <h1 id="aboutus">ABOUT US</h1>  <br>
    <br>
    <br>
    <br>

  <h2> We provide  information just in one tap.
<br>
    The information of individual room power appliances of complete Government Engineering College Hassan is provided here just in one tap.
   <br>Enter the room number and get details of number of fans ,switches and lights present in that particular room  <br>
  <br>
  <br>
  <br>
  <br>
</div>
<div class="gallery">
  <h1 id="gallery">GALLERY </h1>
<img src="2.png" width="465" height="450">
<img src="3.png" width="465" height="450">
<img src="4.png" width="465" height="450">
<img src="1.png" width="465" height="450">
<br>
<img src="5.png" width="465" height="450">
<img src="2.png" width="465" height="450">
<img src="3.png" width="465" height="450">
<img src="4.png" width="465" height="450">
<br>
<br>

</div>
<br>

<br>

<div class="LOGIN">
  
  <form name="loginForm" method="post" action="room.php">
    <table width="40%"  bgcolor="white" align="center">
    
    <tr>
    <td colspan=2><center><font size=10><b> LOGIN </b></font></center></td>
    </tr>
    
    <tr>
    <td>Username:</td>
    <td><input type="text" size=25 name="userid"></td>
    </tr>
    
    <tr>
    <td>Password:</td>
    <td><input type="Password" size=25 name="pwd"></td>
    </tr>
    
    <tr>
    <td ><input type="Reset"></td>
    <td><input type="submit" onclick="return check(this.form)"   value="Login"></td>
    <td><input type="button" value="Go back" onclick="history.back()"></td>
    
    </tr>
    
  </table>
    </form>
    <script language="javascript">
    function check(form)
    {
    
    if(form.userid.value == "gech" && form.pwd.value == "gech")
    {
      return true;
    }
    else
    {
      alert("Error Password or Username")
      return false;
    }
    }
    </script>
   
</div>
<br>
<br>
<br>
<div class="right">
  <h1 id="contactus">CONTACT US</h1>
  <br>

  <br><h2>
    bhoomika m<br>Kavitha Nadig<br>Amreeza<br>Poojitha</h2>
      <br>
      <br>
      <br>
</div>
<br>
<br>
</body>
</html>






