-- MySQL dump 10.13  Distrib 8.0.17, for Linux (x86_64)
--
-- Host: localhost    Database: temp
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `electronic_appliances`
--

DROP TABLE IF EXISTS `electronic_appliances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `electronic_appliances` (
  `ea_name` varchar(100) DEFAULT NULL,
  `ea_id` int(100) NOT NULL AUTO_INCREMENT,
  `switch_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ea_id`),
  KEY `switch_id` (`switch_id`),
  CONSTRAINT `electronic_appliances_ibfk_1` FOREIGN KEY (`switch_id`) REFERENCES `switch` (`switch_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `electronic_appliances`
--

LOCK TABLES `electronic_appliances` WRITE;
/*!40000 ALTER TABLE `electronic_appliances` DISABLE KEYS */;
INSERT INTO `electronic_appliances` VALUES ('fan',1,'s15'),('fan',2,'s16'),('fan',3,'s17'),('fan',4,'s21'),('fan',5,'s22'),('fan',6,'s39'),('fan',7,'s40'),('fan',8,'s41'),('light',9,'s3'),('light',10,'s12'),('light',11,'s13'),('light',12,'s14'),('light',13,'s28'),('light',14,'s29'),('light',15,'s30'),('light',16,'s31'),('light',17,'s32'),('light',18,'s42'),('light',19,'s43'),('light',20,'s4'),('light',21,'s44'),('light',22,'s46'),('light',23,'s47'),('light',24,'s5'),('light',25,'s6'),('light',26,'s7'),('light',27,'s8'),('light',28,'s9'),('light',29,'s10'),('light',30,'s11'),('fan',31,'s58'),('light',32,'s57'),('light',33,'s59'),('light',34,'s60'),('light',35,'s61'),('fan',36,'s67'),('fan',37,'s68'),('fan',38,'s69'),('fan',39,'s70'),('fan',40,'s71'),('light',41,'s77'),('light',42,'s78'),('light',43,'s79'),('light',44,'s80'),('light',45,'s81'),('light',46,'s82'),('light',47,'s83'),('light',48,'s84'),('light',49,'s85'),('light',50,'s86'),('light',51,'s87'),('light',52,'s88'),('light',53,'s89'),('light',54,'s90'),('light',55,'s91'),('light',56,'s92');
/*!40000 ALTER TABLE `electronic_appliances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regulator`
--

DROP TABLE IF EXISTS `regulator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `regulator` (
  `room_id` int(11) DEFAULT NULL,
  `regulator_id` int(11) NOT NULL,
  `switch_id` varchar(100) DEFAULT NULL,
  `fan_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`regulator_id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `regulator_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regulator`
--

LOCK TABLES `regulator` WRITE;
/*!40000 ALTER TABLE `regulator` DISABLE KEYS */;
INSERT INTO `regulator` VALUES (307,1,'s15',1),(307,2,'s16',2),(307,3,'s17',3),(307,4,'s21',4),(307,5,'s22',5),(313,6,'s39',1),(313,7,'s40',2),(313,8,'s41',3),(316,9,'s58',1),(324,10,'s67',1),(324,11,'s68',2),(324,12,'s69',3),(324,13,'s70',4),(324,14,'s71',5);
/*!40000 ALTER TABLE `regulator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (307,'classroom'),(313,'staff roomm'),(316,'HOD room'),(324,'lab');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socket`
--

DROP TABLE IF EXISTS `socket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `socket` (
  `switch_id` varchar(100) DEFAULT NULL,
  `socket_no` int(11) NOT NULL,
  `switch_box_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`socket_no`),
  KEY `switch_id` (`switch_id`),
  KEY `switch_box_id` (`switch_box_id`),
  CONSTRAINT `socket_ibfk_1` FOREIGN KEY (`switch_id`) REFERENCES `switch` (`switch_id`) ON DELETE CASCADE,
  CONSTRAINT `socket_ibfk_2` FOREIGN KEY (`switch_box_id`) REFERENCES `switch_box` (`switch_box_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socket`
--

LOCK TABLES `socket` WRITE;
/*!40000 ALTER TABLE `socket` DISABLE KEYS */;
INSERT INTO `socket` VALUES ('s1',1,1),('s2',2,1),('s18',3,3),('s24',4,4),('s38',5,5),('s48',6,7),('s52',7,7),('s55',8,9),('s56',9,9),('s65',10,10),('s66',11,10),('s76',12,12),('s93',13,14),('s94',14,14),('s95',15,14),('s96',16,15),('s97',17,15),('s98',18,15),('s99',19,15),('s100',20,16),('s101',21,16),('s102',22,16),('s103',23,16),('s104',24,17),('s105',25,17),('s106',26,17),('s107',27,17),('s108',28,18),('s109',29,18),('s110',30,18),('s111',31,18),('s112',32,19),('s113',33,19),('s114',34,19),('s115',35,19),('s116',36,20),('s117',37,20),('s118',38,20),('s119',39,20),('s120',40,21),('s121',41,21),('s122',42,21),('s123',43,21),('s124',44,22),('s125',45,22),('s126',46,22),('s127',47,22),('s128',48,23),('s129',49,23),('s130',50,23),('s131',51,23),('s132',52,24),('s133',53,24),('s134',54,24),('s135',55,24),('s136',56,25),('s137',57,25),('s138',58,25),('s139',59,25),('s140',60,26),('s141',61,26),('s142',62,26),('s143',63,26),('s144',64,27),('s145',65,27),('s146',66,27),('s147',67,27),('s148',68,28),('s149',69,28),('s150',70,28),('s151',71,28),('s152',72,29),('s153',73,29),('s154',74,29),('s155',75,29),('s156',76,30),('s157',77,30),('s158',78,30),('s159',79,30),('s160',80,31),('s161',81,31),('s162',82,31),('s163',83,31),('s164',84,32),('s165',85,32),('s166',86,33),('s167',87,33);
/*!40000 ALTER TABLE `socket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `switch`
--

DROP TABLE IF EXISTS `switch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `switch` (
  `switch_id` varchar(100) NOT NULL,
  `switch_box_id` int(11) DEFAULT NULL,
  `working` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`switch_id`),
  KEY `switch_box_id` (`switch_box_id`),
  CONSTRAINT `switch_ibfk_1` FOREIGN KEY (`switch_box_id`) REFERENCES `switch_box` (`switch_box_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `switch`
--

LOCK TABLES `switch` WRITE;
/*!40000 ALTER TABLE `switch` DISABLE KEYS */;
INSERT INTO `switch` VALUES ('s1',1,NULL),('s10',2,NULL),('s100',15,NULL),('s101',16,NULL),('s102',16,NULL),('s103',16,NULL),('s104',16,NULL),('s105',17,NULL),('s106',17,NULL),('s107',17,NULL),('s108',17,NULL),('s109',18,NULL),('s11',2,NULL),('s110',18,NULL),('s111',18,NULL),('s112',18,NULL),('s113',19,NULL),('s114',19,NULL),('s115',19,NULL),('s116',19,NULL),('s117',20,NULL),('s118',20,NULL),('s119',20,NULL),('s12',2,NULL),('s120',20,NULL),('s121',21,NULL),('s122',21,NULL),('s123',21,NULL),('s124',21,NULL),('s125',22,NULL),('s126',22,NULL),('s127',22,NULL),('s128',22,NULL),('s129',23,NULL),('s13',2,NULL),('s130',23,NULL),('s131',23,NULL),('s132',23,NULL),('s133',24,NULL),('s134',24,NULL),('s135',24,NULL),('s136',24,NULL),('s137',25,NULL),('s138',25,NULL),('s139',25,NULL),('s14',2,NULL),('s140',25,NULL),('s141',26,NULL),('s142',26,NULL),('s143',26,NULL),('s144',26,NULL),('s145',27,NULL),('s146',27,NULL),('s147',27,NULL),('s148',27,NULL),('s149',28,NULL),('s15',3,NULL),('s150',28,NULL),('s151',28,NULL),('s152',28,NULL),('s153',29,NULL),('s154',29,NULL),('s155',29,NULL),('s156',29,NULL),('s157',30,NULL),('s158',30,NULL),('s159',30,NULL),('s16',3,NULL),('s160',30,NULL),('s161',31,NULL),('s162',31,NULL),('s163',31,NULL),('s164',31,NULL),('s165',32,NULL),('s166',32,NULL),('s167',33,NULL),('s168',33,NULL),('s17',3,NULL),('s18',3,NULL),('s19',3,NULL),('s2',1,NULL),('s20',3,NULL),('s21',4,NULL),('s22',4,NULL),('s23',4,NULL),('s24',4,NULL),('s25',5,NULL),('s26',5,NULL),('s27',5,NULL),('s28',5,NULL),('s29',5,NULL),('s3',2,NULL),('s30',5,NULL),('s31',5,NULL),('s32',5,NULL),('s33',5,NULL),('s34',5,NULL),('s35',5,NULL),('s36',5,NULL),('s37',5,NULL),('s38',5,NULL),('s39',6,NULL),('s4',2,NULL),('s40',6,NULL),('s41',6,NULL),('s42',6,NULL),('s43',6,NULL),('s44',6,NULL),('s45',7,NULL),('s46',7,NULL),('s47',7,NULL),('s48',7,NULL),('s49',7,NULL),('s5',2,NULL),('s50',7,NULL),('s51',7,NULL),('s52',7,NULL),('s53',8,NULL),('s54',8,NULL),('s55',9,NULL),('s56',9,NULL),('s57',9,NULL),('s58',9,NULL),('s59',9,NULL),('s6',2,NULL),('s60',9,NULL),('s61',9,NULL),('s62',9,'no'),('s63',9,NULL),('s64',9,NULL),('s65',10,NULL),('s66',10,NULL),('s67',11,NULL),('s68',11,NULL),('s69',11,NULL),('s7',2,NULL),('s70',11,NULL),('s71',12,NULL),('s72',12,NULL),('s73',12,NULL),('s74',12,NULL),('s75',12,NULL),('s76',12,NULL),('s77',12,NULL),('s78',12,NULL),('s79',12,NULL),('s8',2,NULL),('s80',12,NULL),('s81',13,NULL),('s82',13,NULL),('s83',13,NULL),('s84',13,NULL),('s85',13,NULL),('s86',13,NULL),('s87',13,NULL),('s88',13,NULL),('s89',13,NULL),('s9',2,NULL),('s90',13,NULL),('s91',13,NULL),('s92',13,NULL),('s93',14,NULL),('s94',14,NULL),('s95',14,NULL),('s96',14,NULL),('s97',15,NULL),('s98',15,NULL),('s99',15,'yes');
/*!40000 ALTER TABLE `switch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `switch_box`
--

DROP TABLE IF EXISTS `switch_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `switch_box` (
  `switch_box_id` int(11) NOT NULL,
  `room_id` int(11) DEFAULT NULL,
  `no_of_switches` int(11) DEFAULT NULL,
  `no_of_sockets` int(11) DEFAULT NULL,
  `no_of_regulators` int(11) DEFAULT NULL,
  PRIMARY KEY (`switch_box_id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `switch_box_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `switch_box`
--

LOCK TABLES `switch_box` WRITE;
/*!40000 ALTER TABLE `switch_box` DISABLE KEYS */;
INSERT INTO `switch_box` VALUES (1,307,2,2,0),(2,307,5,1,2),(3,307,5,1,2),(4,307,12,0,0),(5,313,14,1,0),(6,313,6,0,3),(7,313,8,2,0),(8,313,2,0,0),(9,316,10,2,1),(10,316,2,2,0),(11,324,4,0,4),(12,324,10,1,1),(13,324,12,0,0),(14,324,4,4,0),(15,324,4,4,0),(16,324,4,4,0),(17,324,4,4,0),(18,324,4,4,0),(19,324,4,4,0),(20,324,4,4,0),(21,324,4,4,0),(22,324,4,4,0),(23,324,4,4,0),(24,324,4,4,0),(25,324,4,4,0),(26,324,4,4,0),(27,324,4,4,0),(28,324,4,4,0),(29,324,4,4,0),(30,324,4,4,0),(31,324,4,4,0),(32,324,2,2,0),(33,324,2,2,0);
/*!40000 ALTER TABLE `switch_box` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-10 11:00:47
