	
	
<?php  include('admin_code.php'); ?>
<?php 
	if (isset($_GET['edit'])) {
		$room_id = $_GET['edit'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM room WHERE room_id=$room_id");

		if (count($record) == 1) {
			$n = mysqli_fetch_array($record);
			$room_name = $n['room_name'];
			$room_id = $n['room_id'];
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Room</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<?php $results = mysqli_query($db, "SELECT * FROM room"); ?>

<table>
	<thead>
		<tr>
			<th>Room ID</th>
			<th>NAME</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['room_id']; ?></td>
			<td><?php echo $row['room_name']; ?></td>
			<td>
				<a href="admin_room.php?edit=<?php echo $row['room_id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="admin_code.php?del=<?php echo $row['room_id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } ?>
</table>
<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
	<form method="post" action="admin_code.php" >
		<div class="input-group">
			<label>Room ID</label>
			<input type="text" name="id" value="<?php echo $room_id ?>">
		</div>
		<div class="input-group">
			<label>Room Name</label>
			<input type="text" name="name" value="<?php echo $room_name ?>">
		</div>
		<div class="input-group">
    <?php if ($update == true): ?>
	<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
<?php else: ?>
	<button class="btn" type="submit" name="save" >Save</button>
<?php endif ?>
		</div>
	</form>
</body>
</html>