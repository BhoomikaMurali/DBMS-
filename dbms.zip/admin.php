<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h1> WELCOME ADMIN</h1>
<div>
	<a href="admin_room.php">
		<button class = "btn">Add Rooms</button>	
	</a>
</div>
<br>
<div>
	<a href="appliance.php">
		<button class="btn" >Add Appliances</button>
	</a>
</div>
</body>
</html>